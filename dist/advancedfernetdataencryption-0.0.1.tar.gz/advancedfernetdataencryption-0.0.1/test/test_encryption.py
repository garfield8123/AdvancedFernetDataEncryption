from AdvancedFernetDataEncryption import *
import json

# Generates the Token and stores the random token into the Token.json file 
def writeJson():
    with open("Token.json") as Token:
        data = json.load(Token)
    for x in data.keys():
        if "Password" in x:
            data.update({x:dataEncrpytion(data.get(x))})
        data.update({"GenerateToken":passwordToken()})
    with open("Token.json", "w") as outfile:
        outfile.write(json.dumps(data))

# Reads all information from Token.json file and stores in the dictionary data
def useJson():
    with open("Token.json") as Token:
        data = json.load(Token)
    return data

writeJson()
